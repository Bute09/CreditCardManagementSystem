package dao;


import java.util.ArrayList;
import java.util.List;
import model.transaction;
import resources.myQuries;

public class TransactionDao extends dbconnection_abstract {
	public List<transaction> gettransactionByZipCode(int ZipCode,int month,  int year) throws Exception {
		myconnection();
		ps = con.prepareStatement(myQuries.transactionByZipCode);
		ps.setInt(1, ZipCode);
		ps.setInt(2, month);
		ps.setInt(3, year);
		rs = ps.executeQuery();
		List <transaction> tList = new ArrayList<transaction>();
		while(rs.next()) {
			transaction t = new transaction(); 
			t.setTransactionId(rs.getInt(1));
			t.setDay(rs.getInt(2));
			t.setMonth(rs.getInt(3));
			t.setYear(rs.getInt(4));
			t.setCardNo(rs.getString(5));
			t.setBranchCode(rs.getInt(6));
			t.setType(rs.getString(7));
			t.setValue(rs.getDouble(8));
			tList.add(t);
		}
			return tList;
			
	//	return null;
	}
	
	
	public transaction gettotalbyType(String type) throws Exception {
		myconnection();
		ps = con.prepareStatement(myQuries.totalByType);
		ps.setString(1, type);
		rs = ps.executeQuery();
		transaction t = new transaction();
		if(rs.next()) {
			t.setCount(rs.getInt(1));
			t.setValue(rs.getDouble(2));
			t.setType(rs.getString(3));
				
		}		
		return t;
	}
	
		
	public transaction gettotalByBranchState(String branchState) throws Exception {
		
		myconnection();
		ps = con.prepareStatement(myQuries.totalByBranchState);
		ps.setString(1, branchState);
		rs = ps.executeQuery();
		transaction t = new transaction();
	
			
		if(rs.next()) {
			
		
			t.setCount(rs.getInt(1));
			t.setValue(rs.getDouble(2));
			t.setBranchState(rs.getString(3));
			return t;
		}
		return  null;
			
		
			
}
}

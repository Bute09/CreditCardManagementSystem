package dao;


import java.util.ArrayList;
import java.util.List;

import model.customers;

import resources.myQuries;

public class CustomersDao extends dbconnection_abstract {

	public customers getcheckAccountDetails(int ssn) throws Exception {
		myconnection();
		ps = con.prepareStatement(myQuries.checkAccountDetails);
		ps.setInt(1, ssn);
		rs = ps.executeQuery();
		customers c = new customers();

		if (rs.next()) {
			// get sets from customer table for this query
			c.setFirstName(rs.getString(1));
			c.setMiddleName(rs.getString(2));
			c.setLastName(rs.getString(3));
			c.setSsn(rs.getInt(4));
			c.setCardNo(rs.getString(5));
			c.setAptNo(rs.getString(6));
			c.setStreetName(rs.getString(7));
			c.setCity(rs.getString(8));
			c.setState(rs.getString(9));
			c.setCountry(rs.getString(10));
			c.setZipCode(rs.getInt(11));
			c.setPhone(rs.getInt(12));
			c.setEmail(rs.getString(13));
			c.setLastUpdated(rs.getString(14));
			return c;
		}
		return c;
	}

	public int getupdatedAccountDetails(int ssn, String column_name, String column_val) throws Exception {
	

			myconnection();
			String format = String.format(myQuries.updatedAccountDetails1 + column_name + myQuries.updatedAccountDetails2);
			ps = con.prepareStatement(format);
			ps.setString(1, column_val);
			ps.setInt(2, ssn);
			
			return ps.executeUpdate();

	}
	

	public customers getmonthlyBill(String cardNo, int ssn, int month, int year) throws Exception {
		myconnection();
		ps = con.prepareStatement(myQuries.monthlyBill);
		ps.setString(1, cardNo);
		ps.setInt(2, ssn);
		ps.setInt(3, month);
		ps.setInt(4, year);
		rs = ps.executeQuery();
		customers c = new customers();
		if (rs.next()) {
			c.setValue(rs.getDouble(1));
			return c;
		}
		return null;
	}

	public customers getmonthlyBillDetails(String cardNo, int ssn, int month, int year) throws Exception {
		myconnection();
		ps = con.prepareStatement(myQuries.monthlyBillDetails);
		ps.setString(1, cardNo);
		ps.setInt(2, ssn);
		ps.setInt(3, month);
		ps.setInt(4, year);
		rs = ps.executeQuery();
		customers c = new customers();
		if (rs.next()) {
			c.setValue(rs.getDouble(1));
			c.setType(rs.getString(2));
			c.setMonth(rs.getInt(3));
			c.setYear(rs.getInt(4));
			return c;
		}
		return null;
	}

	public List<customers> transactionByDates(int scanSsn, String startDate, String endDate) throws Exception {
		myconnection();
		ps = con.prepareStatement(myQuries.transactionByDates);
		ps.setInt(1, scanSsn);
		ps.setString(2, startDate);
		ps.setString(3, endDate);
		rs = ps.executeQuery();
		List<customers> cList = new ArrayList<customers>();
		//Customers TBD = new Customers();
		while(rs.next()) {
			customers c = new customers();
			c.setTransactionId(rs.getInt("TRANSACTION_ID"));
			c.setType(rs.getString("TRANSACTION_TYPE"));
			c.setValue(rs.getDouble("TRANSACTION_VALUE"));
			
			cList.add(c);
		//return c;
		}
	return cList;
	//return null;
	}
}

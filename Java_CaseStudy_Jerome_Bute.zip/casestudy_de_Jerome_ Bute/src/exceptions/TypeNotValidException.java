package exceptions;

public class TypeNotValidException extends Exception {
	public TypeNotValidException(String msg) {
		 super (msg);
		 }
}

package exceptions;

public class CCNotValidException  extends Exception {
	 public CCNotValidException (String msg) {
		 super (msg);
		 }
}

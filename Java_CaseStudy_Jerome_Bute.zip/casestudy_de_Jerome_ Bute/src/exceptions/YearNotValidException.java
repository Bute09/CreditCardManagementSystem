package exceptions;

public class YearNotValidException extends Exception{

	public YearNotValidException(String msg) {
		 super (msg);
		}

}

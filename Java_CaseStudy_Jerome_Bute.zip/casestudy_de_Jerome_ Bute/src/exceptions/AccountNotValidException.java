package exceptions;

public class AccountNotValidException extends Exception {
	public AccountNotValidException(String msg) {
		 super (msg);
		 }
}

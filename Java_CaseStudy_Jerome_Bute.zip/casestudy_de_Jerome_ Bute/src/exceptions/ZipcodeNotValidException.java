package exceptions;

public class ZipcodeNotValidException extends Exception{
	public ZipcodeNotValidException(String msg) {
		 super (msg);
		 }
}

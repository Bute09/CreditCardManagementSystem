package exceptions;

public class DayNotValidException extends Exception {
	 public DayNotValidException(String msg) {
		 super (msg);
		}

}

package exceptions;

public class MonthNotValidException extends Exception{
	 public MonthNotValidException(String msg) {
		 super (msg);
		 }

}

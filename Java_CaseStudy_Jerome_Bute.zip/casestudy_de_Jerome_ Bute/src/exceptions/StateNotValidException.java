package exceptions;

public class StateNotValidException extends Exception {
	public StateNotValidException(String msg) {
	 super (msg);
	}
}

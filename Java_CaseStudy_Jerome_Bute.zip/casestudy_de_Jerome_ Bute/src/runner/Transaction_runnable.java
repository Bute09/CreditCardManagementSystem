package runner;

import java.util.*;
import dao.TransactionDao;
import exceptions.StateNotValidException;
import model.transaction;

public class Transaction_runnable {
	
public void gettransactionByZipCode() throws Exception {			
				Scanner sc = new Scanner(System.in);
				System.out.println("\nEnter a ZipCode: ");
				int scanZip = sc.nextInt();
				System.out.println("\nEnter a Month: ");
				int scanMonth = sc.nextInt();
				System.out.println("\nEnter a Year: ");
				int scanYear = sc.nextInt();        
				TransactionDao td = new TransactionDao ();
				List<transaction> tList = new ArrayList<transaction>();
				tList=td.gettransactionByZipCode(scanZip, scanMonth, scanYear);
				String format = "%-18s  %-18s  %-18s  %-18s  %-18s  %-18s %-18s %-15s\n";
				System.out.printf(format, "Transaction ID", "DAY","MONTH","Year","CARD NO","Branch Code", "Transaction Type", "Transaction Value");		
				for(transaction transaction: tList) {
				System.out.printf(format,  transaction.getTransactionId(),
								   transaction.getDay(),
								   transaction.getMonth(),
								   transaction.getYear(),
								   transaction.getCardNo(),
								   transaction.getBranchCode(),
								   transaction.getType(),
								"$"+transaction.getValue());
		                      
				}
			}
		
 
public void getTotalByType() throws Exception {	
			try {
				Scanner sc = new Scanner(System.in);
				System.out.println("Please enter transaction Type:");
				String type = sc.nextLine();
		
				TransactionDao t = new TransactionDao();
				transaction mytransaction2 = t.gettotalbyType(type);
				String format = "%-20s %-24s  %-15s\n";
				System.out.printf(format,"# of Transactions", "Transaction value", "Transaction Type");
				System.out.printf(format,
						mytransaction2.getCount(),
						"$"+ mytransaction2.getValue(),
							mytransaction2.getType());
			//	System.out.println("Transaction values for " + type + ":$" + mytransaction2.getCount());
				} 
		
			catch (Exception e) {
				e.printStackTrace();
			}

}
		
		
public void gettotalByBranchState() throws Exception {
	Scanner sc = new Scanner(System.in);
	boolean isvalid = false;
	
	while(!isvalid) {
		
			try {
			
				System.out.println("Please enter a branch state:");
				String scanbranchState = sc.next();
				
				if (scanbranchState.length() != 2) {
					System.out.println("Wrong Format, please enter state as NY for new york");
					
				}else {
					
							TransactionDao t = new TransactionDao();
							transaction mytransaction3 = t.gettotalByBranchState(scanbranchState);
							
							if(mytransaction3 != null) {
							
								String format = "%-18s  %-18s  %-15s\n";
								String format2 = "%-18s  %-24s  %-15s\n";
								System.out.printf(format, "# of Transactions","Total Value", "Branch State");		
								System.out.printf(format2,  
												   mytransaction3.getCount(),
												  "$"+ mytransaction3.getValue(),
												   mytransaction3.getBranchState());
								isvalid = true;
								 
							 }else {
								 
								 throw new StateNotValidException("doesnt match the records");
							 }
			}
				
			}catch (Exception e) {
			System.out.println("Invalid input! Try Again!");
			isvalid = false;
			sc.nextLine();
			
			
			
							
			 }	
		}
	}
}

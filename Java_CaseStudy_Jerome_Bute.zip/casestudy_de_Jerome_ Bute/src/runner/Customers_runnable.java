package runner;

import java.util.*;


import dao.CustomersDao;
import exceptions.AccountNotValidException;
import model.customers;


public class Customers_runnable {

	public void getcheckAccountDetails() {

		Scanner sc = new Scanner(System.in);
		try {
			//		System.out.println("\nEnter First Name: ");
			//		String scanFName = sc.nextLine();
			//		System.out.println("\nEnter a Last Name: ");
			//		String scanLName = sc.nextLine();
			System.out.println("\nEnter a SSN: ");
			int scanSsn = sc.nextInt();
			CustomersDao cd = new CustomersDao ();
			customers customers = cd.getcheckAccountDetails(scanSsn);
			String format = "%-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-15s\n";
			System.out.printf(format, "First Name", "Middle Name","Last Name","SSN","CARD NO","Apartment NO",
					"Street Name", "City", "State", "Country", "ZipCode", "Phone","Email", "Last Updated");		
			if (customers != null) {
				System.out.printf(format,  
						customers.getFirstName(),
						customers.getMiddleName(),
						customers.getLastName(),
						customers.getSsn(),
						customers.getCardNo(),
						customers.getAptNo(),
						customers.getStreetName(),
						customers.getCity(),
						customers.getState(),
						customers.getCountry(),
						customers.getZipCode(),
						customers.getPhone(),
						customers.getEmail(),
						customers.getLastUpdated());
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	 
	public void display(int ssn) throws Exception {
	CustomersDao cd = new CustomersDao ();
	customers customers = cd.getcheckAccountDetails(ssn);
	String format = "%-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-18s %-15s\n";
	System.out.printf(format, "First Name", "Middle Name","Last Name","SSN","CARD NO","Apartment NO",
			"Street Name", "City", "State", "Country", "ZipCode", "Phone","Email", "Last Updated");		
	if (customers != null) {
		System.out.printf(format,  
				customers.getFirstName(),
				customers.getMiddleName(),
				customers.getLastName(),
				customers.getSsn(),
				customers.getCardNo(),
				customers.getAptNo(),
				customers.getStreetName(),
				customers.getCity(),
				customers.getState(),
				customers.getCountry(),
				customers.getZipCode(),
				customers.getPhone(),
				customers.getEmail(),
				customers.getLastUpdated());
	}
	}
	
	public void getupdatedAccountDetails() throws Exception {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter SSN");
		 int ssn = sc.nextInt();
		
		 display(ssn);
				
		
		System.out.println("Which account details would you like to update?");
		subMenu();
		int columnchoice = sc.nextInt();
		
		String column_val="",column_name="";
		sc.nextLine();
		
			switch (columnchoice) {
			case 1:
				column_name="First_Name";
				System.out.println("Enter new First Name: ");
				column_val = sc.nextLine();
				break;
			case 2:
				column_name="Middle_Name";
				System.out.println("Enter new Middle Name: ");
				column_val = sc.nextLine();
				break;
			case 3:
				column_name="Last_Name";
				System.out.println("Enter new Last Name: ");
				column_val = sc.nextLine();
				break;
			case 4:
				column_name="Apt_NO";
				System.out.println("Enter new AptNo: ");
				column_val = sc.nextLine();
				break;
			case 5:
				column_name="Street_Name";
				System.out.println("Enter new Street Name: ");
				column_val = sc.nextLine();
				break;
			case 6:
				column_name="Cust_City";
				System.out.println("Enter new City: ");
				column_val = sc.nextLine();
				break;
			case 7:
				column_name="Cust_State";
				System.out.println("Enter new State: ");
				column_val = sc.nextLine();
				break;
			case 8:
				column_name="Cust_Country";
				System.out.println("Enter new Country: ");
				column_val = sc.nextLine();
				break;
			case 9:
				column_name="Cust_Zip";
				System.out.println("Enter new ZipCode: ");
				column_val = sc.nextLine();
				break;
			case 10:
				column_name="Cust_Phone";
				System.out.println("Enter new Phone: ");
				column_val = sc.nextLine();
				break;
			case 11:
				column_name="Cust_Email";
				System.out.println("Enter new Email: ");
				column_val = sc.nextLine();
				break;
			}
			
			
			CustomersDao Display = new CustomersDao();
			Display.getupdatedAccountDetails(ssn, column_name,column_val);
			display(ssn);
	}
	public void subMenu() {
		System.out.println("1. First name");
		System.out.println("2. Middle name");
		System.out.println("3. Last name");
		System.out.println("4. AptNo");
		System.out.println("5. StreetName");
		System.out.println("6. City");
		System.out.println("7. State");
		System.out.println("8. Country");
		System.out.println("9. ZipCode");
		System.out.println("10. Phone");
		System.out.println("11. Email");
	}			

	public void getmonthlyBill() {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Please enter a Card Number:");
			String scanCardNo = sc.nextLine();
			System.out.println("Please enter a SSN:");
			int scanSsn = sc.nextInt();
			System.out.println("Please enter a month:");
			int scanMonth = sc.nextInt();
			System.out.println("Please enter a year:");
			int scanYear = sc.nextInt();

			CustomersDao c = new CustomersDao();
			customers customers = c.getmonthlyBill(scanCardNo, scanSsn, scanMonth, scanYear);
			//		String format = "%-18s %-18s %-18s %-18s %-15s\n";
			//		System.out.printf(format, "Card Number", "SSN", "Month", "Year","Monthly Bill");		
			//		System.out.printf(format, 
			//							customers.getCardNo(),
			//							customers.getSsn(),
			//							customers.getMonth(),
			//							customers.getYear(),
			//						  "$"+ customers.getValue());	
			System.out.println("Monthly Bill for Card No:" + scanCardNo + " is :$" + customers.getValue());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void getmonthlyBillDetails() {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Please enter a Card Number:");
			String scanCardNo = sc.nextLine();
			System.out.println("Please enter a SSN:");
			int scanSsn = sc.nextInt();
			System.out.println("Please enter a month:");
			int scanMonth = sc.nextInt();
			System.out.println("Please enter a year:");
			int scanYear = sc.nextInt();

			CustomersDao c = new CustomersDao();
			customers customers = c.getmonthlyBillDetails(scanCardNo, scanSsn, scanMonth, scanYear);
			String format = " %-18s %-18s %-18s %-18s %-15s\n";
			System.out.printf(format, "Card No", "SSN", "Month", "Year", "Monthly Bill");		
			System.out.printf(format, 
					customers.getCardNo(),
					customers.getSsn(),
					customers.getMonth(),
					customers.getYear(),
					"$"+ customers.getValue());	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void gettransactionByDates() {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Please enter a SSN:");
			int scanSsn = sc.nextInt();
			System.out.println("Please enter a Start Year:");
			String scanYear1 = sc.next();
			System.out.println("Please enter a Month:");
			String scanMonth1 = sc.next();
			System.out.println("Please enter a Day:");
			String scanDay1 = sc.next();
			System.out.println("Please enter a  End Year:");
			String scanYear2 = sc.next();
			System.out.println("Please enter a EndMonth:");
			String scanMonth2 = sc.next();
			System.out.println("Please enter a Day:");
			String scanDay2 = sc.next();

			String dateStart = scanYear1 + scanMonth1 +scanDay1 ;
			String dateEnd = scanYear2+scanMonth2+ scanDay2;

			System.out.println(dateStart);
			System.out.println(dateEnd);

			CustomersDao cd = new CustomersDao();
			List<customers> cList = new ArrayList<customers>();
			cList = cd.transactionByDates(scanSsn,dateStart, dateEnd);

			//customers customers = c.transactionByDates(scanSsn);
		String format = " %-18s %-18s %-18s\n";
		System.out.printf(format, "Transaction ID", "Transaction Type", "Transaction Value");		
			for(customers customers: cList) {
				System.out.printf(format, 
						customers.getTransactionId(),
						customers.getType(),
						"$"+ customers.getValue());
			}
		}	 catch (Exception e) {
			e.printStackTrace();
		}
	}
}


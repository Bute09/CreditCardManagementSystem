package runner;

import java.util.Scanner;

public class Main  {
	public static void main(String[] args) throws Exception {
		
		Scanner sc = new Scanner(System.in);
		int option = 0;
		
		
		while (option != 8) {
			try {
			menu();
			option = sc.nextInt();
			Transaction_runnable tr = new Transaction_runnable();
			Customers_runnable cr = new Customers_runnable();
			switch (option) {
		case 1:
			tr.gettransactionByZipCode();
			break;
		
		case 2:
			tr.getTotalByType();
			break;
			
		case 3:
			tr.gettotalByBranchState();
			break;
		
		case 4:
			cr.getcheckAccountDetails();
			break;
			
		case 5:
			cr.getupdatedAccountDetails();
			break;
		case 6:
			cr.getmonthlyBill();
			//cr.getmonthlyBillDetails();
			break;
		case 7:
			cr. gettransactionByDates();
			break;
		case 8: 
			System.out.println("\nTerminated your connection. Have a nice day!!");
			break;
			}
			
		} catch (Exception e) {
			System.out.println("Please type numerical value 1-8");
			sc.next();
		  }
		}	
			
		sc.close();
	}
			public static void menu() {
				System.out.println("\nChoose an action:");
				System.out.println("1. Display the transactions made by customers living in a given zip code for a given month and year");
				System.out.println("2. Display the number and total values of transactions for a given type");
				System.out.println("3. Display the number and total values of transactions for branches in a given state");
				System.out.println("4. Check the existing account details of a customer");
				System.out.println("5. Modify the existing account details of a customer");
				System.out.println("6. Generate monthly bill for a credit card number for a given month and year");
				System.out.println("7. Display the Transactions made by a customer between two dates");
				System.out.println("8. Quit");
			}
		
}

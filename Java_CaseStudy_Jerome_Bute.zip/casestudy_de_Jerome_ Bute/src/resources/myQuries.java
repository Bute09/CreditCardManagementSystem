package resources;

public class myQuries {
	/*Q1*/
	public final static String  transactionByZipCode = "Select cc.TRANSACTION_ID, cc.DAY, cc.MONTH, cc.YEAR, cc.CREDIT_CARD_NO, cc.BRANCH_CODE, cc.TRANSACTION_TYPE, cc.TRANSACTION_VALUE " +
														"from cdw_sapp_creditcard cc " +
														"join cdw_sapp_customer c " +
														"on c.ssn = cc.CUST_SSN " +
														"where c.CUST_ZIP = ? and cc.month = ? and cc.year = ? " +
														"order by cc.day desc ";
	/*Q2*/
	public final static String totalByType = "select count(*), sum(transaction_value), TRANSACTION_TYPE " +
											"from CDW_SAPP_CREDITCARD " +
											"where TRANSACTION_TYPE = ? " +
											"GROUP by TRANSACTION_TYPE";
	/*Q3*/
	public final static String totalByBranchState = "Select count(*) AS Number_OF_Transactions, sum(transaction_value) AS TOTAL_VALUE, br.BRANCH_STATE " + 
											  "from CDW_SAPP_CREDITCARD cc " +
											  "join cdw_sapp_branch br " +
											  "on cc.BRANCH_CODE  = br.BRANCH_CODE " +
											  "where br.BRANCH_STATE = ? " + 
											  "GROUP by br.BRANCH_STATE ";
	
	/*Q4*/ 
	public final static String checkAccountDetails = "Select c.* " +
													 "from cdw_sapp_customer c " +
													 "where c.SSN = ? ";
	
	/*Q5*/
	public final static String updatedAccountDetails1 = "Update cdw_sapp_customer c " +
													   "set " ;
	public final static String updatedAccountDetails2 ="=? "+
													  "where c.SSN =? ";
													  
	

	/*Q6*/ 
	public final static String monthlyBill = "Select sum(TRANSACTION_VALUE) AS MONTHLY_BILL " +
											 "from cdw_sapp_creditcard " +
											 "where CREDIT_CARD_NO = ? and CUST_SSN = ? and month = ? and year = ?";
			

	/*Q6a*/ 
	public final static String monthlyBillDetails = " Select sum(TRANSACTION_VALUE) AS MONTHLY_BILL, TRANSACTION_TYPE, MONTH, YEAR" +
													"from cdw_sapp_creditcard"+
													"where CREDIT_CARD_NO=? and CUST_SSN = ? and month = ? and year = ?" +
													"group by TRANSACTION_TYPE";
			
			
	/*Q7*/ 
	public final static String transactionByDates = "Select TRANSACTION_ID, TRANSACTION_TYPE, TRANSACTION_VALUE " +
													"from cdw_sapp_creditcard " +
													"where CUST_SSN= ? " +
													"and str_to_date(concat(Year, \"\", Month, \"\", Day),\"%Y%m%d\") >= ? " +
													"and str_to_date(concat(Year, \"\", Month, \"\", Day),\"%Y%m%d\") <= ? " +
													"order by month desc, day desc, year desc; "; 

	
	
	
	
	
	
}
